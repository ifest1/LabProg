INF = 9223372036854775807

vertex, origin, destiny = [int(n) for n in input().split()]
graph = {new_list: [] for new_list in range(1, vertex+1)}

for i in range(vertex-1):
    v1, v2, weight = [int(n) for n in input().split()]
    graph[v1].append((v2, weight))
    graph[v2].append((v1, weight))

def djikstra(graph, source, destiny, distances = {}, prevs = {}):
    visiteds = [False] * (vertex+1)

    queue = [source]
    current = source
    last = destiny
    
    distances = {vertex: INF for vertex in graph}
    distances[current] = 0
    path = []

    while queue:
        current = queue.pop(0)
        
        if current == last:
            while last != None:
                path.append(last)
                last = prevs.get(last, None)
            return distances[destiny], path[::-1]

        for i in graph[current]:
            if not visiteds[i[0]]:
    
                neighbor_distance = distances[i[0]]
                tentative = distances[current] + i[1]
        
                if tentative < neighbor_distance:
                    distances[i[0]] = tentative
                    prevs[i[0]] = current
                
                queue.append(i[0])

        visiteds[current] = True

print(djikstra(graph, origin, destiny))



